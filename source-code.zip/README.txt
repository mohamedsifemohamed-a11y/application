Deux applications (HTML unique + projet Capacitor chacune).
Pour l'APK : envoyer le contenu de chaque dossier (wakil-app, qr-reader) dans un depot GitHub distinct,
puis Actions > Build APK > telecharger app-debug.apk.
L'APK contient la meme page que le site, avec : fonctionnement hors ligne, icone MAGROS,
enregistrement/partage des fichiers Excel et PNG via le menu Android.
